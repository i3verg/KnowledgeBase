import "../../styles/grid.scss";
export { cssManager } from "../../ts-common/CssManager";
export { awaitRedraw } from "../../ts-common/dom";
export { DataCollection, DataProxy } from "../../ts-data";
export { Grid } from "./Grid";
export declare const i18n: any;
